import { PublicationCard } from "@/components/publication-card"
import { TalkCard } from "@/components/talk-card"

const preprints = [
  {
    title: "On the Structure of Algebraic Varieties",
    authors: "O. Nicolosi, A. Collaborator",
    journal: "arXiv preprint",
    year: "2024",
    arxiv: "2024.12345",
    abstract:
      "We investigate the fundamental properties of algebraic varieties and their applications to modern geometric theory.",
  },
  {
    title: "Cohomological Methods in Algebraic Geometry",
    authors: "O. Nicolosi",
    journal: "arXiv preprint",
    year: "2023",
    arxiv: "2023.67890",
    abstract: "This paper develops new cohomological techniques for studying complex algebraic structures.",
  },
]

const publications = [
  {
    title: "Fundamental Theorems in Pure Mathematics",
    authors: "O. Nicolosi, B. Researcher, C. Scholar",
    journal: "Journal of Pure and Applied Mathematics",
    year: "2023",
    volume: "45",
    pages: "123-145",
    doi: "10.1234/jpam.2023.45.123",
    abstract: "We present several fundamental results in pure mathematics with applications to algebraic topology.",
  },
]

const talks = [
  {
    title: "Recent Advances in Algebraic Geometry",
    event: "International Congress of Mathematicians",
    location: "Paris, France",
    date: "July 2024",
    type: "Invited Talk",
  },
  {
    title: "Cohomological Methods and Applications",
    event: "European Mathematical Society Meeting",
    location: "Berlin, Germany",
    date: "March 2024",
    type: "Contributed Talk",
  },
]

const conferences = [
  {
    name: "Algebraic Geometry Symposium",
    location: "Cambridge, UK",
    date: "September 2024",
  },
  {
    name: "Workshop on Modern Algebra",
    location: "Turin, Italy",
    date: "June 2024",
  },
]

export function PublicationSection() {
  return (
    <div className="space-y-16">
      {/* Preprints */}
      <section id="preprints">
        <h2 className="mb-8 text-2xl font-semibold tracking-tight text-foreground">Preprints</h2>
        <div className="space-y-8">
          {preprints.map((pub, index) => (
            <PublicationCard key={index} {...pub} />
          ))}
        </div>
      </section>

      {/* Publications */}
      <section id="publications">
        <h2 className="mb-8 text-2xl font-semibold tracking-tight text-foreground">Publications</h2>
        <div className="space-y-8">
          {publications.map((pub, index) => (
            <PublicationCard key={index} {...pub} />
          ))}
        </div>
      </section>

      {/* Talks */}
      <section id="talks">
        <h2 className="mb-8 text-2xl font-semibold tracking-tight text-foreground">Talks & Presentations</h2>
        <div className="space-y-6">
          {talks.map((talk, index) => (
            <TalkCard key={index} {...talk} />
          ))}
        </div>
      </section>

      {/* Conferences */}
      <section id="conferences">
        <h2 className="mb-8 text-2xl font-semibold tracking-tight text-foreground">Conferences Attended</h2>
        <div className="space-y-4">
          {conferences.map((conf, index) => (
            <div key={index} className="flex flex-col gap-1 border-l-2 border-primary pl-4">
              <h3 className="font-medium text-foreground">{conf.name}</h3>
              <p className="text-sm text-muted-foreground">
                {conf.location} • {conf.date}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
