import Link from "next/link"

export function Header() {
  return (
    <header className="border-b border-border bg-card">
      <div className="mx-auto max-w-4xl px-6 py-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight text-foreground md:text-4xl">Orazio Nicolosi</h1>
            <p className="mt-2 text-base text-muted-foreground md:text-lg">PhD Student in Pure Mathematics</p>
            <p className="mt-1 text-sm text-muted-foreground">Università degli Studi di Torino</p>
          </div>
          <nav className="flex gap-6 text-sm">
            <Link href="#preprints" className="text-muted-foreground transition-colors hover:text-foreground">
              Preprints
            </Link>
            <Link href="#publications" className="text-muted-foreground transition-colors hover:text-foreground">
              Publications
            </Link>
            <Link href="#talks" className="text-muted-foreground transition-colors hover:text-foreground">
              Talks
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}
